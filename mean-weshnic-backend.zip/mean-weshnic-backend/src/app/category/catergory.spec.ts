import { Catergory } from './catergory';

describe('Catergory', () => {
  it('should create an instance', () => {
    expect(new Catergory()).toBeTruthy();
  });
});
