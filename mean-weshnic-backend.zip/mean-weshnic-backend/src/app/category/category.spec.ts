import { category } from './category';

describe('Category', () => {
  it('should create an instance', () => {
    expect(new category()).toBeTruthy();
  });
});
