import { ComponentFixture, TestBed } from '@angular/core/testing';

import { categoryDetailsComponent } from './category-details.component';

describe('categoryDetailsComponent', () => {
  let component: categoryDetailsComponent;
  let fixture: ComponentFixture<categoryDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ categoryDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(categoryDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
