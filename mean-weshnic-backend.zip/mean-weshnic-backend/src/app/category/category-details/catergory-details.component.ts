import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catergory-details',
  templateUrl: './catergory-details.component.html',
  styleUrls: ['./catergory-details.component.css']
})
export class CatergoryDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
