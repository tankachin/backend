import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatergoryDetailsComponent } from './catergory-details.component';

describe('CatergoryDetailsComponent', () => {
  let component: CatergoryDetailsComponent;
  let fixture: ComponentFixture<CatergoryDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CatergoryDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatergoryDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
