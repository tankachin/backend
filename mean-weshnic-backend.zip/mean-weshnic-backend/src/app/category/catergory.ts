export class Catergory {
    _id?: string;
    name: string;
    description: String;
    }
    


