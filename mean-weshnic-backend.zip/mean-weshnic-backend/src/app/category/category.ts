export class category {
    _id?: string;
    name: string;
    description: String;
    }
    


