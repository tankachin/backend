  
import { Injectable } from "@angular/core";
import { category } from "./category";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class categoryService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllcategory() {
    return this.http.get("/api/category");
  }
  getcategory(id: string) {
    let url: string = "/api/category/" + id;
    return this.http.get(url);
  }
  createcategory(data) {
    return this.http.post("/api/category", data, httpOptions);
  }
  updatecategory(id, data) {
    let url: string = "/api/category/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deletecategory(id) {
    let url = "/api/category/" + id;
    return this.http.delete(url, httpOptions);
  }
}