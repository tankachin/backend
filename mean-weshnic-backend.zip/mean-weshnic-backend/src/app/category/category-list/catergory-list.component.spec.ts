import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CatergoryListComponent } from './catergory-list.component';

describe('CatergoryListComponent', () => {
  let component: CatergoryListComponent;
  let fixture: ComponentFixture<CatergoryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CatergoryListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatergoryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
