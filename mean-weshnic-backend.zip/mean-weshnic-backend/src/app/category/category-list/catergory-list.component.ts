import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catergory-list',
  templateUrl: './catergory-list.component.html',
  styleUrls: ['./catergory-list.component.css']
})
export class CatergoryListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
