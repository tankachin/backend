import { ComponentFixture, TestBed } from '@angular/core/testing';

import { categoryListComponent } from './category-list.component';

describe('categoryListComponent', () => {
  let component: categoryListComponent;
  let fixture: ComponentFixture<categoryListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ categoryListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(categoryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
