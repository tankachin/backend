import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppComponent } from './app.component';
import { ContactDetailsComponent } from './contacts/contact-details/contact-details.component';
import { ContactListComponent } from './contacts/contact-list/contact-list.component';
import { CategoryDetailsComponent } from './category/category-details/category-details.component';
import { CategoryListComponent } from './category/category-list/category-list.component';
import { CustomerDetailsComponent } from './customers/customer-details/customer-details.component';
import { CustomerListComponent } from './customers/customer-list/customer-list.component';
import { DepartmentDetailComponent } from './departments/department-detail/department-detail.component';
import { DepartmentListComponent } from './departments/department-list/department-list.component';
import { ManufacturerDetailsComponent } from './manufacturers/manufacturer-details/manufacturer-details.component';
import { ManufacturerListComponent } from './manufacturers/manufacturer-list/manufacturer-list.component';
import { OrderDetailsComponent } from './orders/order-details/order-details.component';
import { OrderListComponent } from './orders/order-list/order-list.component';
import { ProductDetailsComponent } from './products/product-details/product-details.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';


@NgModule({
  declarations: [
    AppComponent,
    ContactDetailsComponent,
    ContactListComponent,
    CategoryDetailsComponent,
    CategoryListComponent,
    CustomerDetailsComponent,
    CustomerListComponent,
    DepartmentDetailComponent,
    DepartmentListComponent,
    ManufacturerDetailsComponent,
    ManufacturerListComponent,
    OrderDetailsComponent,
    OrderListComponent,
    ProductDetailsComponent,
    ProductListComponent,
 
    NavigationBarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    HttpClientModule
  ],
  providers: [ContactService],
  bootstrap: [AppComponent]
})
export class AppModule { }
