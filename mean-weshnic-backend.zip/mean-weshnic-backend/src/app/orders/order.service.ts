  
import { Injectable } from "@angular/core";
import { order } from "./order";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class orderService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllorders() {
    return this.http.get("/api/orders");
  }
  getorder(id: string) {
    let url: string = "/api/orders/" + id;
    return this.http.get(url);
  }
  createorder(data) {
    return this.http.post("/api/orders", data, httpOptions);
  }
  updateorder(id, data) {
    let url: string = "/api/orders/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deleteorder(id) {
    let url = "/api/orders/" + id;
    return this.http.delete(url, httpOptions);
  }
}