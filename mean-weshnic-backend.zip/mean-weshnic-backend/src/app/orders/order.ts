export class Order {
    _id?: string;
    ordernum: string;
    description: String;
    productqty: number;
    ordertotal: number;
}
