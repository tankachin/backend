  
import { Injectable } from "@angular/core";
import { customer } from "./customer";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class customerService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllcustomers() {
    return this.http.get("/api/customers");
  }
  getcustomer(id: string) {
    let url: string = "/api/customers/" + id;
    return this.http.get(url);
  }
  createcustomer(data) {
    return this.http.post("/api/customers", data, httpOptions);
  }
  updatecustomer(id, data) {
    let url: string = "/api/customers/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deletecustomer(id) {
    let url = "/api/customers/" + id;
    return this.http.delete(url, httpOptions);
  }
}