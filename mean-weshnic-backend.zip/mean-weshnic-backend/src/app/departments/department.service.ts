  
import { Injectable } from "@angular/core";
import { Contact } from "./department";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class ContactService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllContacts() {
    return this.http.get("/api/departments");
  }
  getContact(id: string) {
    let url: string = "/api/departments/" + id;
    return this.http.get(url);
  }
  createContact(data) {
    return this.http.post("/api/departments", data, httpOptions);
  }
  updateContact(id, data) {
    let url: string = "/api/departments/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deleteContact(id) {
    let url = "/api/departments/" + id;
    return this.http.delete(url, httpOptions);
  }
}