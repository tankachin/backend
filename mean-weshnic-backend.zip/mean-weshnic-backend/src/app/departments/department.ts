export class Department {
    _id?: string;
    name: string;
    description: String;
    }
