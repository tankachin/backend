import { Manufacturer } from './manufacturer';

describe('Manufacturer', () => {
  it('should create an instance', () => {
    expect(new Manufacturer()).toBeTruthy();
  });
});
