import { Manufacture } from './manufacture';

describe('Manufacture', () => {
  it('should create an instance', () => {
    expect(new Manufacture()).toBeTruthy();
  });
});
