import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manufacturer-details',
  templateUrl: './manufacturer-details.component.html',
  styleUrls: ['./manufacturer-details.component.css']
})
export class ManufacturerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
