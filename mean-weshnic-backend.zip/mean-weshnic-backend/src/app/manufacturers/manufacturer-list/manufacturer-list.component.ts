import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manufacturer-list',
  templateUrl: './manufacturer-list.component.html',
  styleUrls: ['./manufacturer-list.component.css']
})
export class ManufacturerListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
