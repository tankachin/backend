  
import { Injectable } from "@angular/core";
import { manufacturer } from "./manufacturer";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class manufacturerService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllmanufacturers() {
    return this.http.get("/api/manufacturers");
  }
  getmanufacturer(id: string) {
    let url: string = "/api/manufacturers/" + id;
    return this.http.get(url);
  }
  createmanufacturer(data) {
    return this.http.post("/api/manufacturers", data, httpOptions);
  }
  updatemanufacturer(id, data) {
    let url: string = "/api/manufacturers/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deletemanufacturer(id) {
    let url = "/api/manufacturers/" + id;
    return this.http.delete(url, httpOptions);
  }
}