export class Manufacturer {
    _id?: string;
    name: string;
    description: String;
    }

