import { ContactService } from "./../contact.service";
import { Component, OnInit } from "@angular/core";
import { Contact } from "../contact";

@Component({
  selector: "app-contact-list",
  templateUrl: "./contact-list.component.html",
  styleUrls: ["./contact-list.component.css"]
})
export class ContactListComponent implements OnInit {
  contacts: Contact[];
  selectedContact: Contact;

  constructor(private contactService: ContactService) {}

  ngOnInit() {
    this.contactService.getAllContacts().subscribe((contacts: Contact[]) => {
      this.contacts = contacts.map(contact => {
        if (!contact.phone) {
          contact.phone = {
            mobile: "",
            work: ""
          };
        }
        return contact;
      });
    });
  }
  private getIndexOfContact = (contactId: string) => {
    return this.contacts.findIndex(contact => {
      return contact._id === contactId;
    });
  };

  selectContact(contact: Contact) {
    this.selectedContact = contact;
  }

  createNewContact() {
    var contact: Contact = {
      name: "",
      email: "",
      phone: {
        work: "",
        mobile: ""
      }
    };

    // By default, a newly-created contact will have the selected state.
    this.selectContact(contact);
  }

  deleteContact = (contactId: string) => {
    var idx = this.getIndexOfContact(contactId);
    if (idx !== -1) {
      this.contacts.splice(idx, 1);
      this.selectContact(null);
    }
    return this.contacts;
  };

  addContact = (contact: Contact) => {
    this.contacts.push(contact);
    this.selectContact(contact);
    return this.contacts;
  };

  updateContact = (contact: Contact) => {
    let idx = this.getIndexOfContact(contact._id);
    if (idx !== -1) {
      this.contacts[idx] = contact;
      this.selectContact(contact);
    }
    return this.contacts;
  };
}