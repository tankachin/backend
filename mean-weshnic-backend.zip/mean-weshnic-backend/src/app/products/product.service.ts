  
import { Injectable } from "@angular/core";
import { Contact } from "./product";
import { HttpClient, HttpHeaders } from "@angular/common/http";
const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};
@Injectable({
  providedIn: "root"
})
export class ContactService {
  constructor(private http: HttpClient) {}
  result: any;
  getAllContacts() {
    return this.http.get("/api/products");
  }
  getContact(id: string) {
    let url: string = "/api/products/" + id;
    return this.http.get(url);
  }
  createContact(data) {
    return this.http.post("/api/products", data, httpOptions);
  }
  updateContact(id, data) {
    let url: string = "/api/products/" + id;
    return this.http.put(url, data, httpOptions);
  }
  deleteContact(id) {
    let url = "/api/products/" + id;
    return this.http.delete(url, httpOptions);
  }
}