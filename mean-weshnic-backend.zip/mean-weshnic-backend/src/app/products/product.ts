export class Product {
}
