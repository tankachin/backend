const mongoose = require("mongoose");
const catergory = require("../models/catergory");

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
    console.log("ERROR: " + reason);
    res.status(code || 500).json({
        "error": message
    });
}

module.exports = {
    getAllcategory: function (req, res) {
        catergorys.find({})
            .exec(function (err, catergorys) {
                if (err) {
                    handleError(res, err.message, "Failed to get catergorys.");
                } else {
                    res.status(200).json(catergorys);
                }
            });
    },
    addcategory: function (req, res) {
        let newcatergoryDetails = req.body;
        newcatergoryDetails._id = new mongoose.Types.ObjectId();
        if (!newcatergoryDetails.name) {
            handleError(res, "Invalid user input", "Must provide a name.", 400);
        } else {
            let catergory = new catergorys(newcatergoryDetails);
            catergory.save(function (err) {
                if (err) {
                    handleError(res, err.message, "Failed to create new catergory.");
                } else {
                    res.status(201).json(catergory);
                }
            });
        }
    },
    getcatergoryID: function (req, res) {
        console.log(req.params);
        catergorys.findOne({
            _id: req.params.id
        }, function (err, catergory) {
            if (err) {
                handleError(res, err.message, "Failed to get catergory");
            } else {
                res.status(200).json(catergory);
            }
        });
    },
    updatecatergoryID: function (req, res) {
        let updateDoc = req.body;
        delete updateDoc._id;
        catergorys.updateOne({
                _id: req.params.id
            }, updateDoc,
            function (err, catergory) {
                if (err) {
                    handleError(res, err.message, "Failed to update catergory");
                } else {
                    updateDoc._id = req.params.id;
                    res.status(200).json(updateDoc);
                }
            });
    },
    deletecatergoryID: function (req, res) {
        catergorys.deleteOne({
            _id: req.params.id
        }, function (err, result) {
            if (err) {
                handleError(res, err.message, "Failed to delete catergory");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};