const mongoose = require("mongoose");
const orders = require("../models/orders");

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
    console.log("ERROR: " + reason);
    res.status(code || 500).json({
        "error": message
    });
}

module.exports = {
    getAllorders: function (req, res) {
        orders.find({})
            .exec(function (err, orders) {
                if (err) {
                    handleError(res, err.message, "Failed to get orders.");
                } else {
                    res.status(200).json(orders);
                }
            });
    },
    addorders: function (req, res) {
        let neworderDetails = req.body;
        neworderDetails._id = new mongoose.Types.ObjectId();
        if (!neworderDetails.name) {
            handleError(res, "Invalid user input", "Must provide a name.", 400);
        } else {
            let order = new orders(neworderDetails);
            order.save(function (err) {
                if (err) {
                    handleError(res, err.message, "Failed to create new order.");
                } else {
                    res.status(201).json(order);
                }
            });
        }
    },
    getorderID: function (req, res) {
        console.log(req.params);
        orders.findOne({
            _id: req.params.id
        }, function (err, order) {
            if (err) {
                handleError(res, err.message, "Failed to get order");
            } else {
                res.status(200).json(order);
            }
        });
    },
    updateorderID: function (req, res) {
        let updateDoc = req.body;
        delete updateDoc._id;
        orders.updateOne({
                _id: req.params.id
            }, updateDoc,
            function (err, order) {
                if (err) {
                    handleError(res, err.message, "Failed to update order");
                } else {
                    updateDoc._id = req.params.id;
                    res.status(200).json(updateDoc);
                }
            });
    },
    deleteorderID: function (req, res) {
        orders.deleteOne({
            _id: req.params.id
        }, function (err, result) {
            if (err) {
                handleError(res, err.message, "Failed to delete order");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};