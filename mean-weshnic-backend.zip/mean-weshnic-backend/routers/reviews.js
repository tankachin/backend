const mongoose = require("mongoose");
const reviews = require("../models/reviews");

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
    console.log("ERROR: " + reason);
    res.status(code || 500).json({
        "error": message
    });
}

module.exports = {
    getAllreviews: function (req, res) {
        reviews.find({})
            .exec(function (err, reviews) {
                if (err) {
                    handleError(res, err.message, "Failed to get reviews.");
                } else {
                    res.status(200).json(reviews);
                }
            });
    },
    addreviews: function (req, res) {
        let newreviewDetails = req.body;
        newreviewDetails._id = new mongoose.Types.ObjectId();
        if (!newreviewDetails.name) {
            handleError(res, "Invalid user input", "Must provide a name.", 400);
        } else {
            let review = new reviews(newreviewDetails);
            review.save(function (err) {
                if (err) {
                    handleError(res, err.message, "Failed to create new review.");
                } else {
                    res.status(201).json(review);
                }
            });
        }
    },
    getreviewID: function (req, res) {
        console.log(req.params);
        reviews.findOne({
            _id: req.params.id
        }, function (err, review) {
            if (err) {
                handleError(res, err.message, "Failed to get review");
            } else {
                res.status(200).json(review);
            }
        });
    },
    updatereviewID: function (req, res) {
        let updateDoc = req.body;
        delete updateDoc._id;
        reviews.updateOne({
                _id: req.params.id
            }, updateDoc,
            function (err, review) {
                if (err) {
                    handleError(res, err.message, "Failed to update review");
                } else {
                    updateDoc._id = req.params.id;
                    res.status(200).json(updateDoc);
                }
            });
    },
    deletereviewID: function (req, res) {
        reviews.deleteOne({
            _id: req.params.id
        }, function (err, result) {
            if (err) {
                handleError(res, err.message, "Failed to delete review");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};