const mongoose = require("mongoose");
const products = require("../models/products");

// Generic error handler used by all endpoints.
function handleError(res, reason, message, code) {
    console.log("ERROR: " + reason);
    res.status(code || 500).json({
        "error": message
    });
}

module.exports = {
    getAllproducts: function (req, res) {
        products.find({})
            .exec(function (err, products) {
                if (err) {
                    handleError(res, err.message, "Failed to get products.");
                } else {
                    res.status(200).json(products);
                }
            });
    },
    addproducts: function (req, res) {
        let newproductDetails = req.body;
        newproductDetails._id = new mongoose.Types.ObjectId();
        if (!newproductDetails.name) {
            handleError(res, "Invalid user input", "Must provide a name.", 400);
        } else {
            let product = new products(newproductDetails);
            product.save(function (err) {
                if (err) {
                    handleError(res, err.message, "Failed to create new product.");
                } else {
                    res.status(201).json(product);
                }
            });
        }
    },
    getproductID: function (req, res) {
        console.log(req.params);
        products.findOne({
            _id: req.params.id
        }, function (err, product) {
            if (err) {
                handleError(res, err.message, "Failed to get product");
            } else {
                res.status(200).json(product);
            }
        });
    },
    updateproductID: function (req, res) {
        let updateDoc = req.body;
        delete updateDoc._id;
        products.updateOne({
                _id: req.params.id
            }, updateDoc,
            function (err, product) {
                if (err) {
                    handleError(res, err.message, "Failed to update product");
                } else {
                    updateDoc._id = req.params.id;
                    res.status(200).json(updateDoc);
                }
            });
    },
    deleteproductID: function (req, res) {
        products.deleteOne({
            _id: req.params.id
        }, function (err, result) {
            if (err) {
                handleError(res, err.message, "Failed to delete product");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
};